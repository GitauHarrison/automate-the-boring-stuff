Aspiring Andelans understand what classes and objects are, how to design simple data models, and how to apply object-oriented programming principles to solve basic problems.


| What should I  know by the end of this skill?   |      Resources      |
|:-------------|:------------------|
| * What Object Oriented Programming is| [Understand object oriented programming](http://teknadesigns.com/what-is-object-oriented-programming/) |
| * How to explain Object Oriented programming to a six year old| [Object oriented programming made easy](https://medium.freecodecamp.org/object-oriented-programming-concepts-21bb035f7260) |

----------
### ** Click on the image below to watch a video on Object Oriented Programming **
[![4 pillars of OOP](https://i1.wp.com/www.csetutor.com/wp-content/uploads/2018/02/Binary.png?fit=1024%2C512&ssl=1)](https://www.youtube.com/watch?v=pTB0EiLXUC8 "4 pillars of OOP")
----------

### **Knowledge check**
-----------------------

**Click [here](https://goo.gl/forms/ZFMR64BXoIbfrfSq2) to test your knowledge on OOP.**

---------

### ** Implementing Object Oriented Programming**
A. **  When I am faced with a data modeling problem **
- I attempt to identify all the objects, and each object's properties and their behaviours

B. **  When creating a class model for an object **
- I define my object's attributes as variables and behaviour as methods within my class

C. ** When working on codebase that I foresee will grow dramatically **
- I strive to ensure my code is DRY by building reusable components

D. ** When modeling data using OOP **
- I take advantage of inheritance to ensure I am reusing code as much as possible

----------

### **What do I need to believe about Object Oriented Programming:?**
1. Modeling my code in an object oriented way helps me think about problems in a structured way
2. Modeling my code in an object oriented way helps me write sustainable and reusable program components
