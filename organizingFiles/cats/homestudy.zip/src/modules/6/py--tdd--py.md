Aspiring Andelans know what tests are, how to write them, and how the TDD approach can be beneficial in development.


| What should I know by the end of this skill?   |      Resources      |
|:-------------|:------------------|
| * Getting Started With TDD in Python| [Getting started article](https://code.tutsplus.com/tutorials/beginning-test-driven-development-in-python--net-30137) |
| * Getting Started With TDD in Python(Video)|[TDD in python](https://vimeo.com/225565787/e386768a86)|

-------------
### **Click on the image to learn more about TDD in python**

[![TDD in python](https://images.xenonstack.com/blog/Test-Driven-Development-Python.png)](https://www.youtube.com/watch?v=VOqcwrw8CVk "TDD in python")
-------------




