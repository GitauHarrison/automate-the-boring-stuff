Aspiring Andelans value receiving feedback and are able to apply feedback they receive to improve on their performance.

| What do I need to know?|Resource|
|:-------------|:-------------|
| I can describe the following from memory: |- [Seeks feedback](https://vimeo.com/216662854/8400e6ea5b)|
| Importance and benefits of seeking feedback |[5 Tips for Leaders Seeking Feedback](https://trainingindustry.com/articles/leadership/get-feedback-to-get-better-5-tips-for-leaders-seeking-feedback/)|
| * Approaches for constructively and effectively receiving feedback | |


----------
### **Click on the image below to watch a talk about how to use others' feedback to learn and grow | Sheila Heen **

 [![How to use others' feedback to learn and grow | Sheila Heen](https://www.yc.edu/images/news/Feedback-keyboard.jpg)](https://www.youtube.com/watch?v=FQNbaKkYk_Q "How to use others' feedback to learn and grow | Sheila Heen")

 ----------

### ** Demonstrating the ability to seek feedback**

A. When receiving feedback
- I acknowledge receipt of the feedback and the value of the same
- I ensure I stay positive while also seeing the possible value of the feedback
- I take note of the feedback and ensure to follow up with action plans
- I take deliberate steps to act on the feedback received

----------



### **What do I need to believe about databases:?**
1. To reach my potential I must relentlessly seek and act on feedback
2.  Other people’s perspectives matter and add value to my life and work
3. There are valuable truths that I can only understand through feedback
4. It is not enough to ask "What went wrong?" without also asking "What can I try next?"

