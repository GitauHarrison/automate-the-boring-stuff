Aspiring Andelans recognize there is a standard framework within which business people can operate as they communicate and collaborate. Attention to etiquette is a sign of professionalism and respect for others, and it can make positive first impressions while building trust among colleagues.

| What do I need to know?|      Resource       |
|:-------------|:------------------|
| * What Business Etiquette is |  [10 Key Business Etiquette every Professional should know ](https://www.inc.com/ilya-pozin/the-10-business-etiquette-rules-every-professional-should-know.html) |
| * Vital rules of business etiquette | [15 Professional Communication Etiquette Rules](http://www.businessinsider.com/professional-communication-etiquette-rules-2013-12?IR=T)|

----------
 ### **Click on the image below to watch 15 must know business etiquette**

 [![15 must know business etiquette rules](https://www.stoneward.com/wp-content/uploads/2012/12/shutterstock_77075815.jpg)](https://www.youtube.com/watch?v=lGzMmi94Dsc "15 must know business etiquette rules")
----------
### **Knowledge check**
-----------------------
### **Click [here](https://goo.gl/forms/JCo2VGd8dP4RUKPL2) to test your knowledge on business etiquette.**
---------

### ** Additonal Resources**
- [Importance of business Etiquette](http://corp.yonyx.com/customer-service/importance-of-business-etiquette/)
- [21 Vital etiquette rules](https://toggl.com/business-etiquette-rules)
- [Business Etiquette for Job Success](https://www.gcflearnfree.org/print/jobsuccess/business-etiquette?playlist=Job_Success)
- [Communication Etiquette ](https://www.slideshare.net/orangecanton/communication-etiquette)