Aspiring Andelans can read and understand ES6 code.


| What do I need to know?   |      Resources      |
|:-------------|:------------------|
| * A First Look at ES6| [ES6: A First Look](https://medium.com/sons-of-javascript/javascript-an-introduction-to-es6-1819d0d89a0f) |

----------

### ** Demonstrating Skill **
A. **  When I am writing ES6 code  **
-  I follow ES6 best practices and conventions.

----------

### ** What do I need to believe about skill:? **
1. By deeply understanding the main features of ES6 and how they are applied, I become a more effective developer.