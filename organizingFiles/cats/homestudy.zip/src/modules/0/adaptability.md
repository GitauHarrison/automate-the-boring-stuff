Aspiring Andelans understand that they will encounter changes in their work environment and are able to perform at a high level in the face of change.


| What do I need to know?   |      Resources      |
|:-------------|:------------------|
| * The concept of change |
| * The causes, cycles, effects of change
| * How to manage and embrace change ||

### **Click the image below to watch our very own Mukundi Ann talk about adaptability**

----------
[![ADAPTABILITY](https://quotefancy.com/media/wallpaper/3840x2160/1608311-Peter-Hilton-Quote-Adaptability-to-change-is-itself-a-hallmark-of.jpg)](https://vimeo.com/220290465/8ffbb41250 "Adaptability")


----------

### **Demonstrating Adaptability**
A. **  When confronted by change **
- I take steps to understand what changed and how best to respond to the change

B. **  When confronted by change **
- I communicate that I see the value of the change

C. ** When working in a changing environment **
- I ensure to stay calm and focused on the overall goals of the project, company or organization

----------

### **What do I need to believe about adaptability:?**
1. I can adapt to my changing environment
2. Change is inevitable, so I harness it to develop myself and help others grow
