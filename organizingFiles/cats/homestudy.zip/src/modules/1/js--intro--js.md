Aspiring Andelans know what a computer program is and understand the basics. They understand and can explain to their peers what programming is and the general programming concepts. They know the different models of programming, types of programming languages and can give examples of each model and type. They also have the capacity to identify and build the environment that enables them to code.



| What do I need to know?   |      Resources      |
|:-------------|:------------------|
| * Codecademy| [Javascript course](https://www.codecademy.com/learn/learn-javascript) |
| * Javascript Introduction| [MDN](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Introduction) |
| * Javascript| [First Steps](https://developer.mozilla.org/en-US/docs/Learn/JavaScript/First_steps) |
| * JavaScript | [Building Blocks](https://developer.mozilla.org/en-US/docs/Learn/JavaScript/Building_blocks) |

### **Click on the image below for helpful bonus Javascript material**
----------
[![Javascript for absolute beginners](https://cdn-images-1.medium.com/max/1140/1*jnhgiJ5Z16elapyBhf4-9Q.jpeg)](https://www.youtube.com/watch?v=vEROU2XtPR8 "Javascript for absolute beginners")
----------
### **Knowledge check**
----------
### **Click [here](https://goo.gl/forms/1JJ7SWuJ1JwiuKR73) to test your knowledge on JavaScript basics**
---------
