Aspiring Andelans know what a computer program is and understand the basics. They understand and can explain to their peers what programming is and the general programming concepts. They know the different models of programming, types of programming languages and can give examples of each model and type. They also have the capacity to identify and build the environment that enables them to code.



| What do I need to know?   |      Resources      |
|:-------------|:------------------|
| * Google Developers: | [Python Introduction](https://developers.google.com/edu/python/introduction)|
| * * Python learning Scope |[From Zero to Hero](https://medium.com/the-renaissance-developer/learning-python-from-zero-to-hero-8ceed48486d5)|
| * * Codecademy Python Course|[Learn python interactively](https://www.codecademy.com/learn/python)|
| * Recap |[Python Essentials](http://opentechschool.github.io/python-data-intro/core/recap.html)|
| * Learn Python by doing |[Practice as you learn](http://www.learnpython.org/en/Welcome)|

----------
### **Additional resources for learning python**
[Top 3 Python Online Courses](https://medium.com/codingthesmartway-com-blog/top-3-python-online-courses-8091e0dc8a79)
[Python Top 45 Articles version 2018](https://medium.mybridge.co/python-top-45-tutorials-for-the-past-year-v-2018-1b4d46c9e857)

### **Helpful bonus Python material**
-----------
[![Python introduction by Qazi from clever programmer](https://i.ytimg.com/vi/oAz5eIpgTpg/maxresdefault.jpg)](https://www.youtube.com/watch?v=wp15jyylSEQ&list=PL-E5w8McXrZPlid5i4q2txNxCZa9MK8Ws "Introduction to programming")
-------------
### **Knowledge check**
-------------
### **Click [here](https://goo.gl/forms/XFqZOWzdOCl2BRv82) to test your knowledge on python basics**
---------
