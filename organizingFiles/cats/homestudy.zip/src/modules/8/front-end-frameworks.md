| What do I need to know?   |      Resources      |
|:-------------|:------------------|
| * Introduction to frontend frameworks| [Front end engineering](http://www.sparxitsolutions.com/blog/best-css-html-js-front-end-frameworks/) |
| * Introduction to server side frameworks | [Server Side Frameworks](https://developer.mozilla.org/en-US/docs/Learn/Server-side/First_steps/Web_frameworks)
| * Examples of CSS frameworks|[Introduction to Front-end CSS frameworks](https://makeawebsitehub.com/frontend-frameworks-intro/)|
| * Examples of JAVASCRIPT frameworks|[Modern JS frameworks](https://rubygarage.org/blog/best-javascript-frameworks-for-front-end)|
| * Examples of HTML frameworks| |
